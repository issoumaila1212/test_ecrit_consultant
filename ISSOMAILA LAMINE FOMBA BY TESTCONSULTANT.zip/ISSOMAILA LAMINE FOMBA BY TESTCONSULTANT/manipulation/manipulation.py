def filtrer_prenoms(prenoms):
    prenoms_valides = []
    
    for prenom in prenoms:
        if prenom.startswith('A'):
            print(f"{prenom}: prénom valide")
            prenoms_valides.append(prenom)
        else:
            print(f"{prenom}: prénom invalide")
    
    return prenoms_valides

# Exemple d'utilisation
prenoms = ['Alice', 'Bob', 'Anne', 'Charlie', 'Amelia', 'David']
prenoms_valides = filtrer_prenoms(prenoms)

print("Liste des prénoms valides:", prenoms_valides)
