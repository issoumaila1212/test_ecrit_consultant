from django.apps import AppConfig


class Api2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api2'
